package com.example.guessthephrase

import android.content.Context
import android.content.DialogInterface
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    private lateinit var rvMessages: ConstraintLayout
    private lateinit var etguess: EditText
    private lateinit var btGusses: Button
    private lateinit var messages: ArrayList<String>
    private lateinit var tvPhras: TextView
    private lateinit var tvLetter: TextView
    private lateinit var sharedPreferences: SharedPreferences

    private var answer = "you can do it, you are very smart"
    private var userAns = arrayListOf<Char>()
    private var msg = arrayListOf<Char>()
    private var myAnswer = ""
    private var guessedLetters = ""
    private var guessedMessage = '.'
    private var count = 0
    private var find =0
    private var changes=10
    private var first = true
    private var geuss = false
    lateinit var myRV : RecyclerView
    private var HighScore = 0
    var fal = true



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etguess = findViewById(R.id.etGuessField)
        btGusses = findViewById(R.id.btGuessButton)
        btGusses.setOnClickListener { guess() }
        tvPhras = findViewById(R.id.tvPhrase)
        tvLetter = findViewById(R.id.tvLetters)

        myRV=findViewById(R.id.rvMessages)
        messages= ArrayList()
        msg= ArrayList()
        myRV.adapter=recyclerView(this,messages)
        myRV.layoutManager= LinearLayoutManager(this)
        btGusses.setOnClickListener {guess()
            updateText() }
        sharedPreferences = this.getSharedPreferences(
            getString(R.string.preference_file_key), Context.MODE_PRIVATE)
        var  myMessage = sharedPreferences.getString("myMessage", "$HighScore").toString()  // --> retrieves data from Shared Preferences
// We can save data with the following code
        with(sharedPreferences.edit()) {
            putString("myMessage",myMessage)
            apply()
        }
    }

    private fun guess() {
        if(first==true){
            var str = etguess.text.toString().lowercase()
            if (str == answer) {
                Dialog("You win!\n\nPlay again?")
                HighScore = 25

                changes--
            } else {
                messages.add("Wrong guess: $str ")
                msg()
                myAnswer = tvLetters.text.toString()
                tvLetters.text = "please Guess the letter one by one"
                var letter = etguess.text.toString().lowercase()[0]
                println("Here letter[0] = $letter")
                myRV.adapter?.notifyDataSetChanged()
                first = false
//count
            }}
    }
    //Phrase:  *** *** ** **, *** *** **** *****.
    fun msg()
    { println("Here msg")
        for(i in 0..answer.length-1){
            if(answer[i] == ' '){
                msg.add(' ')
                myAnswer += ' '
            }else{
                msg.add('*')
                myAnswer += '*'
                tvPhrase.text = myAnswer
                myRV.adapter?.notifyDataSetChanged()
            }
        }
    }

    private fun updateText() {
        var guessedMessage1=""
        var letter: Char = '.'
        if (etguess.text.toString().length == 1) {
            println("Here update text")
            letter = etguess.text.toString().lowercase()[0]
            println("Here letter[0] = $letter")
            //guessedLetters

            if (!userAns.contains(letter)) {
                println("userAns.contains($letter)")

                if (answer.contains(letter)) {
                    println("answer.contains($letter)")

                    for (i in 0..answer.length - 1) {
                        println("for loop")

                        if (answer[i] == letter) {
                            println("answer[$i] == letter ${answer[i]} \n $msg")
                            find++
                            geuss = true
                            msg[i] = letter
                            // myAnswer = msg[i].toString()
                            userAns.add(letter)
                            guessedLetters = letter.uppercase()
                            tvLetters.text = "You Guessed  ${guessedLetters}"
                            HighScore =find
                            tvHighScore.text ="HighScore: $HighScore"
                            fal = true

                        }else fal=false
                    }

                    if (geuss == true) {

                        fal = true
                        messages.add("You are Guess $letter,  $find letters ")
                        HighScore =find
                        tvHighScore.text ="HighScore: $HighScore"
                        //   myAnswer = msg.toString()
                        var  guessedMessage2 =""
                        for (i in 0..msg.size - 1)
                            guessedMessage2+= msg[i].toString()
                        tvPhrase.text = guessedMessage2
                    } else {
                        if (changes >= 0) {
                            geuss == false
                            changes--
                            messages.add("Ooh Wrong answer  :( ")
                            println("Ooh Wrong guess :( $letter")
                            messages.add("$changes guesses remaining")
                            myRV.adapter?.notifyDataSetChanged()
                        }
                    }
                }
            } else {
                println("Toast")
                Toast.makeText(
                    applicationContext,
                    "Please Guess different letters.",
                    Toast.LENGTH_SHORT
                ).show()
                myRV.adapter?.notifyDataSetChanged()
            }
        } else
            tvLetters.text = "please Guess the letter one by one"

        myAnswer = msg.toString()
        for (i in 0..msg.size - 1)
            guessedMessage1 += msg[i].toString()
        tvPhrase.text = guessedMessage1

        if ((changes >= 0)&&(fal==false)){
            changes--
            messages.add("Ooh Wrong answer  :( ")
            println("Ooh Wrong guess :( $letter")
            messages.add("$changes guesses remaining")
            myRV.adapter?.notifyDataSetChanged()}

        if (!tvPhrase.text.contains("*"))
            Dialog("You are win \n Play again? ")
/*
        if (geuss == true) {
            var guessedMessage1 = ""
            messages.add("You are Guess $letter,  $find letters ")
            //   myAnswer = msg.toString()
            for (i in 0..msg.size - 1)
                guessedMessage1 += msg[i].toString()
            tvPhrase.text = guessedMessage1


        } else {
            if (changes >= 0) {
                messages.add("Ooh Wrong answer  :( ")
                println("Ooh Wrong guess :( $letter")
                messages.add("$changes guesses remaining")
                myRV.adapter?.notifyDataSetChanged()
            }

 */
        myRV.adapter?.notifyDataSetChanged()

        sharedPreferences = this.getSharedPreferences(
            getString(R.string.preference_file_key), Context.MODE_PRIVATE)
        var myMessage =
            sharedPreferences.getString("myMessage", "$guessedMessage1")
                .toString()  // --> retrieves data from Shared Preferences
// We can save data with the following code
        with(sharedPreferences.edit()) {
            putString("myMessage", myMessage)
            apply()
        }
    }


    private fun Dialog(title: String) {

        // build alert dialog
        val dialogBuilder = AlertDialog.Builder(this)

        // set message of alert dialog
        dialogBuilder.setMessage(title)
            // if the dialog is cancelable
            .setCancelable(false)
            // positive button text and action
            .setPositiveButton("Yes", DialogInterface.OnClickListener {
                    dialog, id -> this.recreate()
                etguess.text.clear()
            })
            // negative button text and action
            .setNegativeButton("No", DialogInterface.OnClickListener {
                    dialog, id -> dialog.cancel()
            })

        // create dialog box
        val alert = dialogBuilder.create()
        // set title for alert dialog box
        alert.setTitle("Guess Game ")
        // show alert dialog
        alert.show()
        myRV.adapter?.notifyDataSetChanged()
    }

}